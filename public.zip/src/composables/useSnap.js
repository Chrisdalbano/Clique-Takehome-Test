import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger"

export function useScrollSnapping(...ids) {
  function goToSection(section) {
    console.log(section.offsetHeight)
    console.log(section)
    gsap.to(window, {
      scrollTo: {
        y: section.clientHeight,
        autoKill: false,
        ease: "Power3.easeInOut",
        toggleActions: "play reverse play reverse",
      },
      duration: 0.5,
    });
    // section.scrollIntoView({behavior: "smooth"});
  }

  function setup() {
    for (const id of ids) {
      const element = document.getElementById(id);
      if (element == null) continue;

      ScrollTrigger.create({
        trigger: element,
        onEnter: () => goToSection(element),
      });

      ScrollTrigger.create({
        trigger: element,
        start: "bottom bottom",
        markers: true,
        onEnterBack: () => goToSection(element),
      });
    }
  }

  return { setup };
}
