<template>
  <HeroSection />
  <AboutSection />
</template>

<script setup>
import HeroSection from "../components/HeroSection.vue";
import AboutSection from "../components/AboutSection.vue";


</script>
